package com.example.flutter_application_inaper

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
