// ignore_for_file: constant_identifier_names

class Routes {
 static const HOME = '/';
 static const PAGINA_DADOS = '/pagina_tarefas';
 static const PAGINA_ASSISTIDO = '/pagina_assitido';
 static const PAGINA_POSHOME = '/poshome_page';
 }