class Pessoa {
 String? nome;
 String? sobrenome;
 String? email;
 String? senha;
 String? confSena;
 String? assistido;
}

